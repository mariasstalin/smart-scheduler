
# Patient Priority Scorer

This project provides a machine learning model to score patients for doctor appointments based on several factors. The model is built using LightGBM.

## Features

The model uses the following features to predict the priority score:

- `is_vip`: (Boolean) [0/1] - 1 for VIP patients.
- `severity_level`: (int) [0-10] - The severity of the patient's condition.
- `acceptance_rate`: (Decimal) [0.0 - 100.0] - The patient's historical appointment acceptance rate.
- `time_difference`: (integer) [0-5] - The difference between the desired and available appointment time.
- `time_consistency_std_dev`: (number) [15 - 120] - The standard deviation of the patient's past appointment times.

## Getting Started

### Prerequisites

- Python 3.7+
- A virtual environment (recommended)

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository_url>
   cd patient-priority-scorer
   ```

2. **Create and activate a virtual environment:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install the dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. **Generate synthetic data:**

   First, you need to generate the synthetic data for training the model.

   ```bash
   python generate_data.py
   ```

   This will create a `patient_data.csv` file.

2. **Train the model:**

   Next, train the LightGBM model using the generated data.

   ```bash
   python train_model.py
   ```

   This will train the model and save it as `lgbm_model.txt`.

3. **Make predictions:**

   You can use the `predict.py` script to get a priority score for a new patient.

   ```bash
   python predict.py
   ```

   You can also import the `predict_priority_score` function into your own application to use the model.

## Model Details

- **Model:** LightGBM Regressor
- **Objective:** Regression
- **Metric:** Root Mean Squared Error (RMSE)

