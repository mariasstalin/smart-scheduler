from datetime import datetime

import pandas as pd
import lightgbm as lgb

# Load the model
bst = lgb.Booster(model_file='service/lgbm_model.txt')


def predict_priority_score(cancelled_slot_time, patient_data):
    """
    Predicts the priority score for patients.

    Args:
        cancelled_slot_time (datetime): Cancelled slots datetime
        patient_data (list): A dictionary with the patient's data.

    Returns:
        return user details with score
    """
    cancelled_slot_minutes = cancelled_slot_time.hour * 60 + cancelled_slot_time.minute
    feature_list = []
    for patient_info in patient_data:
        features = {'id': patient_info['id'], 'is_vip': 1 if patient_info.get('isVIP') else 0, 'acceptance_rate': (
                                                                                                                              patient_info[
                                                                                                                                  "totalNotificationsResponded"] /
                                                                                                                              patient_info[
                                                                                                                                  "totalNotificationsSent"]) * 100,
                    "severity_level": 1 if patient_info.get("severityLevel") else 0}
        history = patient_info['bookingHistory']
        if not history:
            features['time_difference'] = 180
            features['time_consistency_std_dev'] = 90
        else:
            timestamps = pd.to_datetime(history)
            minutes_from_midnight = (timestamps.hour * 60 + timestamps.minute).values
            avg_minutes = minutes_from_midnight.mean()

            features['time_difference'] = abs(cancelled_slot_minutes - avg_minutes)
            features['time_consistency_std_dev'] = minutes_from_midnight.std(ddof=0)
        feature_list.append(features)
    # Create a DataFrame from the input data
    # print(feature_list)
    df = pd.DataFrame(feature_list)

    # Ensure the order of columns is the same as in the training data
    features = ['is_vip', 'severity_level', 'acceptance_rate', 'time_difference', 'time_consistency_std_dev']
    data = df[features]

    # Predict the score
    df["score"] = bst.predict(data)
    result = df.sort_values(by="score", ascending=False)
    # print(result[['id', 'score']].to_string(index=False))
    return result.to_json(orient='records', lines=True)

if __name__ == '__main__':
    # Example usage
    patient_data = [{
        "id": "User001",
        'is_vip': 1,
        'severity_level': 8,
        "totalNotificationsResponded": 8,
        "totalNotificationsSent": 10,
        "bookingHistory": ["2025-07-01T13:00:00Z", "2025-08-15T13:15:00Z", "2025-09-03T13:05:00Z"]
    },
        {
            "id": "User002",
        'is_vip': 0,
        'severity_level': 2,
        "totalNotificationsResponded": 6,
        "totalNotificationsSent": 10,
        "bookingHistory": ["2025-07-01T13:00:00Z", "2025-08-15T17:00:00Z", "2025-09-03T15:00:00Z"]
    }]
    cancelled_slot_time = datetime.strptime("13:00", "%H:%M")

    score = predict_priority_score(cancelled_slot_time, patient_data=patient_data)
    # print(score)
    # print(score[['id', 'score']].to_string(index=False))
